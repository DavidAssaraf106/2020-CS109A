Title: S-Section 04: Regularization and Model Selection
Category: sections
Slug: section4
Author: Marios Mattheakis, Hayden Joy
Date: 2020-10-02
Tags:  model selection, cross validation, ridge, lasso, regularization, standarization, normalization

## Jupyter Notebooks

- [S-Section 4: Regularization and Model Selection ]({static}notebook/cs109a_section_4.ipynb)

